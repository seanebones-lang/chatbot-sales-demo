#!/bin/bash
# Islamic Study Guide iOS App - Installation Helper
# Run this script to set up the app on your iOS device

echo "📱 Islamic Study Guide iOS App Installation Helper"
echo "=================================================="
echo ""

# Check if we're on macOS
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "✅ Detected macOS"
    echo ""
    echo "📋 Installation Steps:"
    echo "1. Open Safari on your iOS device"
    echo "2. Navigate to: islamic-study-guide-mobile.html"
    echo "3. Tap Share button → Add to Home Screen"
    echo "4. Tap 'Add' to confirm"
    echo ""
    echo "🚀 Quick Launch:"
    echo "   open islamic-study-guide-mobile.html"
    echo ""
    
    # Offer to open the file
    read -p "Would you like to open the mobile app now? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        open islamic-study-guide-mobile.html
        echo "✅ Opened in default browser"
    fi
else
    echo "⚠️  This script is designed for macOS"
    echo "📱 For iOS installation, transfer files to your device"
    echo "   and follow the installation guide"
fi

echo ""
echo "📖 For detailed instructions, see: IOS_INSTALLATION_GUIDE.md"
echo "🎉 Installation complete!"
